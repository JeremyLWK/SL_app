//
//  FirstViewController.swift
//  Assign2
//
//  Created by Chunlei Gao on 20/5/18.
//  Copyright © 2018 Chunlei Gao. All rights reserved.
//

import UIKit

var name = ["Apple", "Banana", "Pear", "delete1",]
var quantity = ["500g", "300g", "400g", "500g",]
var price = ["$3.5", "$4.5", "$5.5", "$6.5",]

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        tableView.delegate = self
        tableView.dataSource = self
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return name.count
        
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "customCell") as! CustomTableViewCell
        cell.itemName.text = name[indexPath.row]
        cell.itemImage.image = UIImage(named:name[indexPath.row])
        cell.itemQuantity.text = quantity[indexPath.row]
        cell.itemPrice.text = price[indexPath.row]
    
        return cell
    }
//delete item function
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == UITableViewCellEditingStyle.delete
        {
            name.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }

}

